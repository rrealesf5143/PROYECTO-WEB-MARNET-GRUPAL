A Pen created at CodePen.io. You can find this one at https://codepen.io/ccamacho5237/pen/LXdWPp.

 